<?php

class AgentShop{
    
public function OffertList($price_min,$price_max,$forwho,$peryferia,$where_work){
if ($forwho == '1') {
	
	if ($where_work == 'mobilnie') {

		if ($peryferia == 'tak') {

			$query="select * from products where price_min >= '$price_min' and price_max <= '$price_max' and procesor >= 1000 and ram >= 1 and karta_graficzna >=1 and bateria >=8000 and (myszka = '1' OR klawiatura = '1' OR monitor = '1') ORDER BY price_min DESC";
			$result = mysql_query($query) or die(mysql_error());
			
		}elseif ($peryferia == 'nie') {

			$query="select * from products where price_min >= '$price_min' and price_max <= '$price_max' and procesor >= 1000 and ram >= 1 and karta_graficzna >=1 and bateria >=8000 ORDER BY price_min DESC";
			$result = mysql_query($query) or die(mysql_error());

		}

	}elseif ($where_work == 'stacjonarnie') {
		if ($peryferia == 'tak') {

			$query="select * from products where price_min >= '$price_min' and price_max <= '$price_max' and procesor >= 1000 and ram >= 1 and karta_graficzna >=1 and bateria >=5000 and (myszka = '1' OR klawiatura = '1' OR monitor = '1') ORDER BY price_min DESC";

			$result = mysql_query($query) or die(mysql_error());
		}elseif ($peryferia == 'nie') {

			$query="select * from products where price_min >= '$price_min' and price_max <= '$price_max' and procesor >= 1000 and ram >= 1 and karta_graficzna >=1 and bateria >=5000 ORDER BY price_min DESC";
			$result = mysql_query($query) or die(mysql_error());

		}
	}

}elseif ($forwho == '2') {
	if ($where_work == 'mobilnie') {

		if ($peryferia == 'tak') {
			
			$query="select * from products where price_min >= '$price_min' and price_max <= '$price_max' and procesor >= 3000 and ram >= 6 and karta_graficzna >=2 and bateria >=8000 and dysk >=1000 and (myszka = '1' OR klawiatura = '1' OR monitor = '1') ORDER BY price_min DESC";
			$result = mysql_query($query) or die(mysql_error());

		}elseif ($peryferia == 'nie') {
			$query="select * from products where price_min >= '$price_min' and price_max <= '$price_max' and procesor >= 3000 and ram >= 6 and karta_graficzna >=2 and bateria >=8000 and dysk >=1000 ORDER BY price_min DESC";
			$result = mysql_query($query) or die(mysql_error());
		}

	}elseif ($where_work == 'stacjonarnie') {
		if ($peryferia == 'tak') {
			$query="select * from products where price_min >= '$price_min' and price_max <= '$price_max' and procesor >= 3000 and ram >= 6 and karta_graficzna >=2 and bateria >=7000 and dysk >=1000 and (myszka = '1' OR klawiatura = '1' OR monitor = '1') ORDER BY price_min DESC";
			$result = mysql_query($query) or die(mysql_error());
		}elseif ($peryferia == 'nie') {
			$query="select * from products where price_min >= '$price_min' and price_max <= '$price_max' and procesor >= 3000 and ram >= 6 and karta_graficzna >=2 and bateria >=7000 and dysk >=1000 ORDER BY price_min DESC";
			$result = mysql_query($query) or die(mysql_error());
		}
	}
}elseif ($forwho == '3') {
	if ($where_work == 'mobilnie') {

		if ($peryferia == 'tak') {
			$query="select * from products where price_min >= '$price_min' and price_max <= '$price_max' and procesor >= 4000 and ram >=12 and karta_graficzna >=4 and bateria >=8000 and dysk >=500 and (myszka = '1' OR klawiatura = '1' OR monitor = '1') ORDER BY price_min DESC";
			$result = mysql_query($query) or die(mysql_error());
		}elseif ($peryferia == 'nie') {
			$query="select * from products where price_min >= '$price_min' and price_max <= '$price_max' and procesor >= 4000 and ram >=12 and karta_graficzna >=4 and bateria >=8000 and dysk >=500 ORDER BY price_min DESC";
			$result = mysql_query($query) or die(mysql_error());
		}

	}elseif ($where_work == 'stacjonarnie') {
		if ($peryferia == 'tak') {
			$query="select * from products where price_min >= '$price_min' and price_max <= '$price_max' and procesor >= 4000 and ram >=12 and karta_graficzna >=4 and bateria >=7500 and dysk >=500 and (myszka = '1' OR klawiatura = '1' OR monitor = '1') ORDER BY price_min DESC";
			$result = mysql_query($query) or die(mysql_error());
		}elseif ($peryferia == 'nie') {
			$query="select * from products where price_min >= '$price_min' and price_max <= '$price_max' and procesor >= 4000 and ram >=12 and karta_graficzna >=4 and bateria >=7500 and dysk >=500  ORDER BY price_min DESC";
			$result = mysql_query($query) or die(mysql_error());
		}
	}
}

return @$result;
}

}

class AgentSeller{

	public $id;
	public $procesor;
	public $ram;
	public $kartagraficzna;
	public $dysk;
	public $cena;

	public function getoffer($price_min,$price_max,$forwho,$peryferia,$where_work,$waga_forwho,$waga_peryferia,$waga_where_work)
	{
		$agentShop = new AgentShop();
		
        $result = $agentShop->OffertList($price_min,$price_max,$forwho,$peryferia,$where_work); 
		$result2 = mysql_fetch_array($result); 
        do{
			if($waga_peryferia == 3)
			{
                if($result2["myszka"] == '1' && $result2["klawiatura"] == '1' && $result2["monitor"] && '1'){
					$this->id = $result2["Id"];
					$this->procesor = $result2["procesor"];
					$this->ram = $result2["ram"];
					$this->kartagraficzna = $result2["karta_graficzna"];
					$this->dysk = $result2["dysk"];
					$this->cena = $result2["price_min"];
			}
			}elseif($waga_peryferia == 2){
				if($result2["myszka"] == '1' && $result2["klawiatura"] == '1' || $result2["monitor"] && '1'){
					 $this->id = $result2["Id"];
					 $this->procesor = $result2["procesor"];
					 $this->ram = $result2["ram"];
					 $this->kartagraficzna = $result2["karta_graficzna"];
					 $this->dysk = $result2["dysk"];
					 $this->cena = $result2["price_min"];
			 }
			}elseif($waga_peryferia == 1){
				if($result2["myszka"] == '1' || $result2["klawiatura"] == '1' || $result2["monitor"] || '1'){
				$this->id = $result2["Id"];
				$this->procesor = $result2["procesor"];
				$this->ram = $result2["ram"];
				$this->kartagraficzna = $result2["karta_graficzna"];
				$this->dysk = $result2["dysk"];
				$this->cena = $result2["price_min"];
			 }
			 }
		 	} while($result2 = mysql_fetch_array($result) );    	
			}

			
	public function zwroc(){
		if($this->id == null){
		echo "Nie znaleziono produktu";
		}else
		{
		echo " Id : $this->id";
		echo "Procesor : $this->procesor";
		echo "Ram : $this->ram";
		echo "Karta Graficzna : $this->kartagraficzna";
		echo "dysk : $this->dysk";
		echo "cena : $this->cena";
		}
	}		
	}
	